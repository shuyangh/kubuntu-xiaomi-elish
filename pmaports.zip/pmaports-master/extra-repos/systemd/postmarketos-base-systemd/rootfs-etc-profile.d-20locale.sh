# Important: alpine-baselayout sets LANG here, which can override systemd-localed,
# so this file has been stubbed out
#
# Use `localectl set-locale` instead.
# See `man 8 systemd-localed` and `man 5 locale.conf`
