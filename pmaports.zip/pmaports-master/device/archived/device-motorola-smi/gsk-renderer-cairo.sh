#!/bin/sh
export GSK_RENDERER=cairo
