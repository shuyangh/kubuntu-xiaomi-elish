#!/bin/sh

echo 720,3840 > /sys/devices/virtual/graphics/fb0/virtual_size
