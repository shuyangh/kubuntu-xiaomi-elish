#!/bin/sh

# set framebuffer resolution
echo 240,640 > /sys/class/graphics/fb0/virtual_size


