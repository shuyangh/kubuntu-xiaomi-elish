#!/bin/sh

# enable display
echo 0 0 > /sys/class/graphics/fb0/pan
echo 0 0 > /sys/class/graphics/fb0/pan
