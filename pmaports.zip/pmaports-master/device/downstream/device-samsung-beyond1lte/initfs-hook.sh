#!/bin/sh

echo 16 > /sys/devices/platform/19030000.decon_f/graphics/fb0/bits_per_pixel
