echo 1080,4800 > /sys/class/graphics/fb0/virtual_size
