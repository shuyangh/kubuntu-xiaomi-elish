echo 4 > /sys/devices/platform/android_usb/usb_function_switch
