# Avoid automatic reboot
echo 0 > /proc/sys/kernel/hung_task_timeout_secs
