echo 1 > /sys/devices/soc.0/78b7000.i2c/i2c-3/3-0020/f54/reset
