#!/bin/sh

# Fix brightness
echo 91 > /sys/class/leds/lcd-backlight/brightness

