#!/bin/sh

# ask sway, phosh and other wlroots-based compositors to start headless too.
export WLR_LIBINPUT_NO_DEVICES=1
