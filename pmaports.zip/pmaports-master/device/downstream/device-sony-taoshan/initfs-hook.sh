#!/bin/sh
echo "Start the screen enlightener script"
/bin/sh /usr/sbin/sony-taoshan-screen-enlightener >/tmp/sony-taoshan-screen-enlightener.log 2>&1 </dev/null &
