#!/bin/sh

echo 1 > /sys/class/android_usb/android0/unlocked
