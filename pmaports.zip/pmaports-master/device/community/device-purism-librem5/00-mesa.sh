export GDK_GL=gles
export GST_GL_API=gles2
export ETNA_MESA_DEBUG=nir
