# https://source.puri.sm/Librem5/librem5-base/-/commit/11cf55f56593aee5ac2aca7adfbd650d09993e2f
# enables xwayland acceleration
export ETNA_MESA_DEBUG=nir
