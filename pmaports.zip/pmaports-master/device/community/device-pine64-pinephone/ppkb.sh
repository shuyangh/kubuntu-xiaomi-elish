#!/bin/sh
export XKB_DEFAULT_MODEL=ppkb
