# fix artifacts and tearing in GNOME and GTK4
export FD_MESA_DEBUG=nobin
