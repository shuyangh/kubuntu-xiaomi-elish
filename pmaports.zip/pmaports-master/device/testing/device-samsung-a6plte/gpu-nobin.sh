# Disable GPU binning to fix GTK4
export FD_MESA_DEBUG=nobin
