# Mesa's LLVM JIT is crashing with SIGILL
# https://gitlab.freedesktop.org/mesa/mesa/-/issues/13314
export GALLIUM_DRIVER=softpipe
