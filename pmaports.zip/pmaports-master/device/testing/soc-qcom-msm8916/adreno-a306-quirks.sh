#!/bin/sh

# New GTK renderer crashes a306.
export GSK_RENDERER=cairo
