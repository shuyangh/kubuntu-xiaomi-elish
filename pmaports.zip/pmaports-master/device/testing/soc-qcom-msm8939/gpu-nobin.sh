export FD_MESA_DEBUG=nobin
