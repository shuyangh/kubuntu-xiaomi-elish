export KWIN_DRM_DEVICE_NODE=/dev/dri/card1
