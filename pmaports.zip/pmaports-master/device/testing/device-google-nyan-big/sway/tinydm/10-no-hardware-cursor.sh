#!/bin/sh

# A workaround for missing cursor issue

export WLR_NO_HARDWARE_CURSORS=1
